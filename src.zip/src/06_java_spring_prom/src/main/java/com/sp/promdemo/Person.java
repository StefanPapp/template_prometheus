package com.sp.promdemo;

public class Person {
}

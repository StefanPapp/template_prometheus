# Simple Prometheus Java Example

This is a simple example of how to export a Counter with Prometheus. 

The original sample, I got from http://www.robustperception.io/instrumenting-java-with-prometheus/
